package mobAppTaskService;

import org.junit.Test;

import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testCreateTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");

        assertEquals("1234567890", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }
}
