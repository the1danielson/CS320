package mobAppTaskService;

import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.*;

public class TaskServiceTest {
    private TaskService taskService;

    @Before
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);

        Map<String, Task> tasks = taskService.getTasks();
        assertTrue(tasks.containsKey("1234567890"));
        assertEquals(task, tasks.get("1234567890"));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);

        taskService.deleteTask("1234567890");

        Map<String, Task> tasks = taskService.getTasks();
        assertFalse(tasks.containsKey("1234567890"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);

        taskService.updateTaskName("1234567890", "New Task Name");

        Map<String, Task> tasks = taskService.getTasks();
        assertEquals("New Task Name", tasks.get("1234567890").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1234567890", "Task Name", "Task Description");
        taskService.addTask(task);

        taskService.updateTaskDescription("1234567890", "New Task Description");

        Map<String, Task> tasks = taskService.getTasks();
        assertEquals("New Task Description", tasks.get("1234567890").getDescription());
    }
}
