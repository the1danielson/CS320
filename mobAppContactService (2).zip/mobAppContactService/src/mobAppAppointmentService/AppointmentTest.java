package mobAppAppointmentService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentID() {
        String appointmentID = "A001";
        Appointment appointment = new Appointment(appointmentID, new Date(), "Appointment description");

        Assertions.assertEquals(appointmentID, appointment.getAppointmentId());
        
        // Attempt to update the appointment ID
        String newAppointmentID = "A002";
        appointment.setAppointmentId(newAppointmentID);

        Assertions.assertEquals(newAppointmentID, appointment.getAppointmentId());
    }

    @Test
    public void testAppointmentDate() {
        Date appointmentDate = new Date();
        Appointment appointment = new Appointment("A001", appointmentDate, "Appointment description");

        Assertions.assertEquals(appointmentDate, appointment.getAppointmentDate());
    }

    @Test
    public void testAppointmentDescription() {
        String appointmentDescription = "Appointment description";
        Appointment appointment = new Appointment("A001", new Date(), appointmentDescription);

        Assertions.assertEquals(appointmentDescription, appointment.getDescription());

        // Attempt to set a longer description
        String longerDescription = "This is a longer appointment description that exceeds the limit of 50 characters";
        appointment.setDescription(longerDescription);

        Assertions.assertEquals(longerDescription, appointment.getDescription());
    }
}
