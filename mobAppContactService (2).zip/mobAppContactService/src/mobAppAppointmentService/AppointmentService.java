package mobAppAppointmentService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AppointmentService {
    private List<Appointment> appointments;
    // pulls appointments from a list
    
    public AppointmentService() {
        this.appointments = new ArrayList<>();
    }

    public void addAppointment(Appointment appointment) {
        if (isAppointmentIdUnique(appointment.getAppointmentId())) {
            appointments.add(appointment);
        // creates new appointment if Id is unique
        } else {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        // gives error message if appointment Id exists
        }
    }

    public void deleteAppointment(String appointmentId) {
        Iterator<Appointment> iterator = appointments.iterator();
        boolean appointmentFound = false;
        while (iterator.hasNext()) {
            Appointment appointment = iterator.next();
            if (appointment.getAppointmentId().equals(appointmentId)) {
                iterator.remove();
            // deletes appointment as long as Id matches
                appointmentFound = true;
                break;
            }
        }
        if (!appointmentFound) {
            throw new IllegalArgumentException("Appointment not found.");
        // throws error message if appointment does not exist
        }
    }

    public List<Appointment> getAppointments() {
        return appointments;
        // lists appointments
    }

    private boolean isAppointmentIdUnique(String appointmentId) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equals(appointmentId)) {
                return false;
            // checks for unique appointment Id
            }
        }
        return true;
    }
}
