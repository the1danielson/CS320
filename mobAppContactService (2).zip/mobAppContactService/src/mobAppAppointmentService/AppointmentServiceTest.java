package mobAppAppointmentService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    public void setup() {
        appointmentService = new AppointmentService();
    // initialize a new Appointment Service
    }

    @Test
    public void testAddAppointment() {
        Appointment appointment = new Appointment("A001", new Date(), "Appointment description"); 
        // new appointment format
        appointmentService.addAppointment(appointment); 										  
        // starts add new appointment service
        List<Appointment> appointments = appointmentService.getAppointments();
        // checks list for current appointments
        Assertions.assertEquals(1, appointments.size());
        Assertions.assertEquals(appointment, appointments.get(0));
    }

    @Test
    public void testAddDuplicateAppointmentId() {
        Appointment appointment1 = new Appointment("A001", new Date(), "Appointment 1 description");
        Appointment appointment2 = new Appointment("A001", new Date(), "Appointment 2 description"); 
        // format of checking two appointments for duplicate information
        appointmentService.addAppointment(appointment1);
        // checks list for current appointments
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
        // either throws error for duplicate or adds new appointment
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appointment = new Appointment("A001", new Date(), "Appointment description");
        // format of information to be deleted
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("A001");
        // deletes format of appointment 
        List<Appointment> appointments = appointmentService.getAppointments();
        Assertions.assertEquals(0, appointments.size());
        // updates appointments list
    }

    @Test
    public void testDeleteNonExistingAppointment() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("A001"));
        // either throws error for non-existing appointment or deletes appointment
    }

    @Test
    public void testDeleteExistingAppointment() {
        Appointment appointment = new Appointment("A001", new Date(), "Appointment description");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("A001");
        List<Appointment> appointments = appointmentService.getAppointments();
        Assertions.assertEquals(0, appointments.size());
    // tests process of deleting an existing appointment
    }

    @Test
    public void testDeleteAppointmentWithMultipleAppointments() {
        Appointment appointment1 = new Appointment("A001", new Date(), "Appointment 1 description");
        Appointment appointment2 = new Appointment("A002", new Date(), "Appointment 2 description");
        appointmentService.addAppointment(appointment1);
        appointmentService.addAppointment(appointment2);
        appointmentService.deleteAppointment("A001");
        List<Appointment> appointments = appointmentService.getAppointments();
        Assertions.assertEquals(1, appointments.size());
        Assertions.assertEquals(appointment2, appointments.get(0));
    // tests deletion of appointments with more than one appointment.
    }
}
