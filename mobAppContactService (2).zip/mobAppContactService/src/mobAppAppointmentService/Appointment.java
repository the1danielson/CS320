package mobAppAppointmentService;

import java.util.Date;

public class Appointment {
    private String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    // appointment contents
    }

    public String getAppointmentId() {
        return appointmentId;
    // get method of AppointmentId
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    // get method for AppointmentDate
    }

    public String getDescription() {
        return description;
    // get method for Description
    }

    public void setAppointmentId(String newAppointmentId) {
        this.appointmentId = newAppointmentId;
    // set method for AppointmentId
    }

    public void setDescription(String newDescription) {
        this.description = newDescription;
    // set method for Description
    }
}
