package mobAppContactService;

public class Contact {
    private String contactId; // Private field to store the contact ID
    String firstName; // Package-private field to store the first name
    String lastName; // Package-private field to store the last name
    String phone; // Package-private field to store the phone number
    String address; // Package-private field to store the address

    // Constructor with parameters for all fields
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Constructor with two parameters (stub)
    public Contact(String string, String string2) {
		// constructor stub
	}

    // Getter method for contactId field
    public String getContactId() {
        return contactId;
    }

    // Getter method for firstName field
    public String getFirstName() {
        return firstName;
    }

    // Getter method for lastName field
    public String getLastName() {
        return lastName;
    }

    // Getter method for phone field
    public String getPhone() {
        return phone;
    }

    // Getter method for address field
    public String getAddress() {
        return address;
    }
}
