package mobAppContactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    Map<String, Contact> contacts, packages;

    public ContactService() {
        contacts = new HashMap<>();
    }

    
    
    public void addContact(Contact contact) {
        String contactId = contact.getContactId();
        if (!contacts.containsKey(contactId)) {
            contacts.put(contactId, contact);
        }
    }

    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        if (contacts.containsKey(contactId)) {
            Contact contact = contacts.get(contactId);
            contact.firstName = firstName;
        }
    }

    public void updateLastName(String contactId, String lastName) {
        if (contacts.containsKey(contactId)) {
            Contact contact = contacts.get(contactId);
            contact.lastName = lastName;
        }
    }

    public void updatePhone(String contactId, String phone) {
        if (contacts.containsKey(contactId)) {
            Contact contact = contacts.get(contactId);
            contact.phone = phone;
        }
    }

    public void updateAddress(String contactId, String address) {
        if (contacts.containsKey(contactId)) {
            Contact contact = contacts.get(contactId);
            contact.address = address;
        }
    }

}