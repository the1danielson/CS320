package mobAppContactService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


public class ContactServiceTest {

    ContactService contactService = new ContactService();

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("123", "John", "Doe", "1234567890", "Address");
        Contact contact2 = new Contact("123", "Jane", "Smith", "0987654321", "New Address");

        contactService.addContact(contact1);
        contactService.addContact(contact2);

        assertEquals(1, contactService.contacts.size());
        assertEquals("John", contactService.contacts.get("123").getFirstName());
        assertEquals("Doe", contactService.contacts.get("123").getLastName());
    }

    @Test
    public void testAddContact() {
        new Contact("1234567890", "John");
    }
    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        
        // Adding a contact to the contactService
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "Address");
        contactService.addContact(contact);

        // Deleting an existing contact
        contactService.deleteContact("123");
        assertNull(contactService.contacts.get("123"));
        
        // Deleting a non-existent contact
        contactService.deleteContact("456");
        assertNull(contactService.contacts.get("456"));
    }
    @Test
    public void testUpdateFirstName() {
        ContactService contactService = new ContactService();
        
        // Adding a contact to the contactService
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "Address");
        contactService.addContact(contact);

        // Updating the first name of an existing contact
        contactService.updateFirstName("123", "Jane");
        assertEquals("Jane", contactService.contacts.get("123").firstName);
        
        // Updating the first name of a non-existent contact
        contactService.updateFirstName("456", "Alice");
        assertNull(contactService.contacts.get("456"));
    }
    
    @Test
    public void testUpdateLastName() {
        ContactService contactService = new ContactService();
        
        // Adding a contact to the contactService
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "Address");
        contactService.addContact(contact);

        // Updating the last name of an existing contact
        contactService.updateLastName("123", "Smith");
        assertEquals("Smith", contactService.contacts.get("123").lastName);
        
        // Updating the last name of a non-existent contact
        contactService.updateLastName("456", "Johnson");
        assertNull(contactService.contacts.get("456"));
    }
    
    @Test
    public void testUpdatePhone() {
        ContactService contactService = new ContactService();
        
        // Adding a contact to the contactService
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "Address");
        contactService.addContact(contact);

        // Updating the phone number of an existing contact
        contactService.updatePhone("123", "9876543210");
        assertEquals("9876543210", contactService.contacts.get("123").phone);
        
        // Updating the phone number of a non-existent contact
        contactService.updatePhone("456", "5555555555");
        assertNull(contactService.contacts.get("456"));
    }
    
    @Test
    public void testUpdateAddress() {
        ContactService contactService = new ContactService();
        
        // Adding a contact to the contactService
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "Address");
        contactService.addContact(contact);

        // Updating the address of an existing contact
        contactService.updateAddress("123", "New Address");
        assertEquals("New Address", contactService.contacts.get("123").address);
        
        // Updating the address of a non-existent contact
        contactService.updateAddress("456", "Some Address");
        assertNull(contactService.contacts.get("456"));
    }
}